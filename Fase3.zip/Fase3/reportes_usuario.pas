unit reportes_usuario;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Process, StrUtils, FileUtil, Dialogs,
  usuarios, bandejas, lista_doble, cola_correos, pila_papelera, contactos,
  app_state, avl_borradores, bst_contactos, btree_favoritos;

procedure GenerarReportesUsuarioPorEmail(const email: string; const BaseDir: string = '');

procedure ReporteCorreosRecibidos(const userEmail, carpeta: string);
procedure ReportePapelera(const userEmail, carpeta: string);
procedure ReporteProgramados(const userEmail, carpeta: string);
procedure ReporteContactos(const userEmail, carpeta: string);
procedure GenerarReporteBorradoresAVLPorEmail(const UsuarioEmail: String);
procedure GenerarReporteContactosBSTPorEmail(const UsuarioEmail: String);
procedure SyncBSTContactosDesdeLista(const ownerEmail: String);
procedure GenerarReporteFavoritosBTreePorEmail(const UsuarioEmail: String);

procedure ReporteLogueos(const carpeta: string);
procedure GenerarReporteMiLogueoPorEmail(const UsuarioEmail: String);



implementation


function AppDir: string;
begin
  Result := IncludeTrailingPathDelimiter(ExtractFilePath(ParamStr(0)));
end;

function MkUserFolder(const usuarioSistema, BaseDir: string): string;
var dirBase, folder: string;
begin
  if BaseDir <> '' then dirBase := IncludeTrailingPathDelimiter(BaseDir)
                   else dirBase := AppDir;
  folder := IncludeTrailingPathDelimiter(dirBase) + usuarioSistema + '-Reportes';
  ForceDirectories(folder);
  Result := folder;
end;

procedure SaveText(const Path, TextOut: string);
var sl: TStringList;
begin
  sl := TStringList.Create;
  try sl.Text := TextOut; sl.SaveToFile(Path);
  finally sl.Free; end;
end;

function Esc(const s: string): string;
begin
  Result := StringReplace(s, '"', '\"', [rfReplaceAll]);
end;

function Id(const prefix, raw: string): string;
var s: string;
begin
  s := raw;
  s := StringReplace(s,'@','_at_',[rfReplaceAll]);
  s := StringReplace(s,'.','_',[rfReplaceAll]);
  s := StringReplace(s,'-','_',[rfReplaceAll]);
  s := StringReplace(s,'+','_',[rfReplaceAll]);
  s := StringReplace(s,' ','_',[rfReplaceAll]);
  Result := prefix + s;
end;

function Q(const s: string): string; inline; begin Result := '"' + s + '"'; end;

function RunDot(const dotPath, pngPath: string): boolean;
var P: TProcess;
begin
  Result := False;
  if not FileExists(dotPath) then Exit;
  P := TProcess.Create(nil);
  try
    P.Executable := 'dot';
    P.Parameters.Add('-Tpng');
    P.Parameters.Add('-o'); P.Parameters.Add(pngPath);
    P.Parameters.Add(dotPath);
    P.Options := [poWaitOnExit, poUsePipes];
    try
      P.Execute;
      Result := (P.ExitStatus = 0) and FileExists(pngPath);
    except
      Result := False;
    end;
  finally
    P.Free;
  end;
end;

function BuscarEmailPorUsuario(const usuarioSistema: string): string;
var it: PUsuario;
begin
  Result := '';
  it := ListaUsuarios;
  while it <> nil do
  begin
    if SameText(it^.usuario, usuarioSistema) then
    begin
      Result := it^.email;
      Exit;
    end;
    it := it^.siguiente;
  end;
end;

//Correos Recibidos
procedure ReporteCorreosRecibidos(const userEmail, carpeta: string);
var
  dot: TStringList; rutaDot, rutaPng: string;
  pb: PBandeja; cur: PCorreo; i: Integer; prevId, nowId: string;
begin
  rutaDot := IncludeTrailingPathDelimiter(carpeta) + 'correos_recibidos.dot';
  rutaPng := IncludeTrailingPathDelimiter(carpeta) + 'correos_recibidos.png';

  dot := TStringList.Create;
  try
    dot.Add('digraph CorreosRecibidos {');
    dot.Add('  graph [splines=ortho, bgcolor="white"];');
    dot.Add('  rankdir=LR;');
    dot.Add('  node [shape=record, style="rounded,filled", fillcolor="#C9DFEC", fontname="Helvetica"];');
    dot.Add('  edge [color="#2E2E2E", arrowsize=0.8];');
    dot.Add('  subgraph cluster_lista { label="Correos Recibidos ('+Esc(userEmail)+')"; labelloc=top; fontsize=22; style="rounded"; color="#C0C0C0";');

    pb := ObtenerBandejaPtr(userEmail);
    if pb = nil then
    begin
      dot.Add('    empty [label="(sin bandeja para el usuario)"];');
    end
    else
    begin
      cur := pb^.cabeza; i := 0; prevId := '';
      while cur <> nil do
      begin
        nowId := 'n'+IntToStr(i);
        dot.Add(Format('    %s [label="{ID: %d|Remitente: %s|Asunto: %s|Fecha: %s|Estado: %s}"];',
          [nowId, cur^.id, Esc(cur^.remitente), Esc(cur^.asunto), Esc(cur^.fecha), Esc(cur^.estado)]));
        if prevId <> '' then
        begin
          dot.Add(Format('    %s -> %s;', [prevId, nowId]));
          dot.Add(Format('    %s -> %s;', [nowId, prevId]));
        end;
        prevId := nowId; cur := cur^.siguiente; Inc(i);
      end;
      if i = 0 then dot.Add('    empty [label="(sin correos)"];');
    end;

    dot.Add('  }'); dot.Add('}');
    SaveText(rutaDot, dot.Text);
  finally
    dot.Free;
  end;

  RunDot(rutaDot, rutaPng);
end;

//Papelera
procedure ReportePapelera(const userEmail, carpeta: string);
var
  dot: TStringList; rutaDot, rutaPng: string;
  it: PPilaNodo; idx: Integer; nowId, prevId: string;
begin
  rutaDot := IncludeTrailingPathDelimiter(carpeta) + 'papelera.dot';
  rutaPng := IncludeTrailingPathDelimiter(carpeta) + 'papelera.png';

  dot := TStringList.Create;
  try
    dot.Add('digraph Papelera {');
    dot.Add('  graph [splines=ortho, bgcolor="white"];');
    dot.Add('  rankdir=TB;');
    dot.Add('  node [shape=box, style="filled", fillcolor="#FFECB3", fontname="Helvetica"];');
    dot.Add('  edge [arrowhead=vee];');
    dot.Add('  subgraph cluster_pila { label="Papelera ('+Esc(userEmail)+')"; labelloc=top; fontsize=22; style="rounded"; color="#C0C0C0";');

    it := PapeleraGlobal.tope; idx := 0; prevId := '';
    while it <> nil do
    begin
      nowId := 'p'+IntToStr(idx);
      dot.Add(Format('    %s [label="[%s] %s"];',
        [nowId, Esc(it^.dato.estado), Esc(it^.dato.asunto)]));
      if prevId <> '' then
        dot.Add(Format('    %s -> %s;', [prevId, nowId]));
      prevId := nowId;
      it := it^.siguiente; Inc(idx);
    end;
    if idx = 0 then dot.Add('    empty [label="(papelera vacía)"];');

    dot.Add('  }'); dot.Add('}');
    SaveText(rutaDot, dot.Text);
  finally
    dot.Free;
  end;

  RunDot(rutaDot, rutaPng);
end;

//Correos Programados
procedure ReporteProgramados(const userEmail, carpeta: string);
var
  dot: TStringList; rutaDot, rutaPng: string;
  it: PColaNodo; idx: Integer; prevId, nowId: string;
begin
  rutaDot := IncludeTrailingPathDelimiter(carpeta) + 'programados.dot';
  rutaPng := IncludeTrailingPathDelimiter(carpeta) + 'programados.png';

  dot := TStringList.Create;
  try
    dot.Add('digraph Programados {');
    dot.Add('  graph [splines=ortho, bgcolor="white"];');
    dot.Add('  rankdir=LR;');
    dot.Add('  node [shape=record, style="rounded,filled", fillcolor="#D1C4E9", fontname="Helvetica"];');
    dot.Add('  edge [arrowhead=vee];');
    dot.Add('  subgraph cluster_cola { label="Correos Programados ('+Esc(userEmail)+')"; labelloc=top; fontsize=22; style="rounded"; color="#C0C0C0";');

    it := ColaGlobal.frente; idx := 0; prevId := '';
    while it <> nil do
    begin
      if SameText(it^.dato.remitente, userEmail) then
      begin
        nowId := 'c'+IntToStr(idx);
        dot.Add(Format('    %s [label="{%s %s|Asunto: %s|Para: %s}"];',
          [nowId, Esc(it^.dato.fecha), Esc(it^.dato.hora),
           Esc(it^.dato.asunto), Esc(it^.dato.destinatario)]));
        if prevId <> '' then dot.Add(Format('    %s -> %s;', [prevId, nowId]));
        prevId := nowId;
      end;
      it := it^.siguiente; Inc(idx);
    end;
    if prevId = '' then dot.Add('    empty [label="(sin programados del usuario)"];');

    dot.Add('  }'); dot.Add('}');
    SaveText(rutaDot, dot.Text);
  finally
    dot.Free;
  end;

  RunDot(rutaDot, rutaPng);
end;

//Contactos
procedure ReporteContactos(const userEmail, carpeta: string);
var
  dot: TStringList; rutaDot, rutaPng: string;
  head, it: PContacto; idx: Integer; firstId, prevId, nowId: string;
begin
  rutaDot := IncludeTrailingPathDelimiter(carpeta) + 'contactos.dot';
  rutaPng := IncludeTrailingPathDelimiter(carpeta) + 'contactos.png';

  dot := TStringList.Create;
  try
    dot.Add('digraph Contactos {');
    dot.Add('  graph [splines=ortho, bgcolor="white"];');
    dot.Add('  rankdir=LR;');
    dot.Add('  node [shape=box, style="rounded,filled", fillcolor="#B2DFDB", fontname="Helvetica"];');
    dot.Add('  edge [arrowhead=vee];');
    dot.Add('  subgraph cluster_circular { label="Contactos ('+Esc(userEmail)+')"; labelloc=top; fontsize=22; style="rounded"; color="#C0C0C0";');


    head := nil; it := ListaContactos.cabeza;
    if it <> nil then
    begin
      repeat
        if SameText(it^.ownerEmail, userEmail) then
        begin head := it; Break; end;
        it := it^.siguiente;
      until it = ListaContactos.cabeza;
    end;

    if head = nil then
      dot.Add('    empty [label="(sin contactos del usuario)"]')
    else
    begin
      idx := 0; prevId := ''; firstId := '';
      it := head;
      repeat
        nowId := 'k'+IntToStr(idx);
        dot.Add(Format('    %s [label="%s\n(%s)"];', [nowId, Esc(it^.nombre), Esc(it^.email)]));
        if prevId <> '' then dot.Add(Format('    %s -> %s;', [prevId, nowId]));
        if firstId = '' then firstId := nowId;
        prevId := nowId;
        it := it^.siguiente; Inc(idx);
      until (it = head) or (idx > 10000);
      if (firstId <> '') and (firstId <> prevId) then
        dot.Add(Format('    %s -> %s;', [prevId, firstId]));
    end;

    dot.Add('  }'); dot.Add('}');
    SaveText(rutaDot, dot.Text);
  finally
    dot.Free;
  end;

  RunDot(rutaDot, rutaPng);
end;

//Borradores
procedure GenerarReporteBorradoresAVLPorEmail(const UsuarioEmail: String);
var
  userCarp, dirU, dotPath, dotFile, pngFile: String;
  P: TProcess;
  atPos: SizeInt;

begin
  atPos := Pos('@', UsuarioEmail);
  if atPos > 1 then
    userCarp := Copy(UsuarioEmail, 1, atPos - 1)
  else
    userCarp := 'usuario';

  dirU := userCarp + '-Reportes' + DirectorySeparator;
  ForceDirectories(dirU);

  dotFile := dirU + 'borradores_avl.dot';
  pngFile := dirU + 'borradores_avl.png';


  BAVL_ToDOT(BorradoresAVL, dotFile);

  dotPath := '/usr/bin/dot';
  if FileExists(dotPath) then
  begin
    P := TProcess.Create(nil);
    try
      P.Executable := dotPath;
      P.Parameters.Add('-Tpng');
      P.Parameters.Add(dotFile);
      P.Parameters.Add('-o');
      P.Parameters.Add(pngFile);
      P.Options := [poWaitOnExit];
      P.Execute;
    finally
      P.Free;
    end;
  end
  else
  begin
  end;
end;

//Favoritos
procedure GenerarReporteFavoritosBTreePorEmail(const UsuarioEmail: String);
var
  usuarioCarp, dirU, dotFile, pngFile, dotPath: String;
  P: TProcess;
begin
  usuarioCarp := Copy(UsuarioEmail, 1, Pos('@', UsuarioEmail) - 1);
  if usuarioCarp = '' then usuarioCarp := 'usuario';
  dirU := usuarioCarp + '-Reportes' + DirectorySeparator;
  ForceDirectories(dirU);

  dotFile := dirU + 'favoritos_btree.dot';
  pngFile := dirU + 'favoritos_btree.png';

  BFav_ToDOT(FavoritosBTree, dotFile);

  dotPath := '/usr/bin/dot';
  if not FileExists(dotPath) then Exit;

  P := TProcess.Create(nil);
  try
    P.Executable := dotPath;
    P.Parameters.Add('-Tpng');
    P.Parameters.Add(dotFile);
    P.Parameters.Add('-o');
    P.Parameters.Add(pngFile);
    P.Options := [poWaitOnExit];
    P.Execute;
  finally
    P.Free;
  end;
end;

procedure GenerarReporteContactosBSTPorEmail(const UsuarioEmail: String);
var
  atPos: SizeInt;
  userCarp, dirU, dotFile, pngFile, dotPath: String;
  P: TProcess;
begin
  SyncBSTContactosDesdeLista(UsuarioEmail);

  atPos := Pos('@', UsuarioEmail);
  if atPos > 1 then userCarp := Copy(UsuarioEmail, 1, atPos - 1)
               else userCarp := 'usuario';
  dirU := userCarp + '-Reportes' + DirectorySeparator;
  ForceDirectories(dirU);

  dotFile := dirU + 'contactos_bst.dot';
  pngFile := dirU + 'contactos_bst.png';

  BST_ToDOT(ContactosBST, dotFile);

  dotPath := FindDefaultExecutablePath({$IFDEF WINDOWS}'dot.exe'{$ELSE}'dot'{$ENDIF});
  if (dotPath = '') and FileExists('/usr/bin/dot') then dotPath := '/usr/bin/dot';

  if (dotPath = '') or (not FileExists(dotPath)) then
  begin
    ShowMessage('Graphviz no encontrado: se generó "'+dotFile+'" pero no el PNG.');
    Exit;
  end;

  P := TProcess.Create(nil);
  try
    P.Executable := dotPath;
    P.Parameters.Add('-Tpng');
    P.Parameters.Add(dotFile);
    P.Parameters.Add('-o');
    P.Parameters.Add(pngFile);
    P.Options := [poWaitOnExit];
    P.Execute;

    if P.ExitStatus <> 0 then
      ShowMessage('Graphviz falló (exit='+IntToStr(P.ExitStatus)+'). Revisa el .dot.');
  finally
    P.Free;
  end;
end;


procedure GenerarReportesUsuarioPorEmail(const email: string; const BaseDir: string);
var usuarioSistema, carpeta: string;
begin
  if Trim(email) = '' then
    raise Exception.Create('Email vacío.');

  usuarioSistema := Copy(email, 1, Pos('@', email) - 1);
  if usuarioSistema = '' then
    usuarioSistema := StringReplace(email, '@', '_at_', [rfReplaceAll]);

  carpeta := MkUserFolder(usuarioSistema, BaseDir);

  ReporteCorreosRecibidos(email, carpeta);
  ReportePapelera(email, carpeta);
  ReporteProgramados(email, carpeta);
  ReporteContactos(email, carpeta);
end;

procedure SyncBSTContactosDesdeLista(const ownerEmail: String);
var
  p: PContacto;
  C: TBSTContacto;
begin
  BST_Init(ContactosBST);
  if (ListaContactos.cabeza = nil) then Exit;

  p := ListaContactos.cabeza;
  repeat
    if CompareText(p^.ownerEmail, ownerEmail) = 0 then
    begin
      C.email    := p^.email;
      C.nombre   := p^.nombre;
      C.telefono := p^.telefono;
      BST_Insert(ContactosBST, C);
    end;
    p := p^.siguiente;
  until p = ListaContactos.cabeza;
end;

procedure ReporteLogueos(const carpeta: string);
var
  dot   : TStringList;
  rutaDot, rutaPng: string;
  i, n  : Integer;
  e     : TLogEntry;
  prevIdx: Integer;

  function Esc(const s: string): string;
  begin
    Result := StringReplace(s, '"', '\"', [rfReplaceAll]);
  end;

begin

  rutaDot := IncludeTrailingPathDelimiter(carpeta) + 'control_logueo.dot';
  rutaPng := IncludeTrailingPathDelimiter(carpeta) + 'control_logueo.png';

  dot := TStringList.Create;
  try
    dot.Add('digraph ControlLogueo {');
    dot.Add('  graph [bgcolor="white"];');
    dot.Add('  rankdir=LR;');
    dot.Add('  node [shape=record, style="rounded,filled", fillcolor="#E3F2FD", fontname="Helvetica"];');
    dot.Add('  edge [arrowhead=vee, color="#555555"];');
    dot.Add('  label="Reporte Logueo"; labelloc=top; fontsize=22;');

    n := LoginLogCount;
    if n = 0 then
    begin
      dot.Add('  empty [shape=box, label="(sin registros)"];');
    end
    else
    begin
      for i := 0 to n-1 do
      begin
        e := GetLoginLog(i);
        if IsRootUser(e.usuario) then
          Continue;

        dot.Add(Format(
          '  n%d [label="{#%d|Usuario: %s|Entrada: %s|Salida: %s}"];',
          [i, i+1, Esc(e.usuario), Esc(e.entrada), Esc(e.salida)]
        ));
      end;

      prevIdx := -1;
      for i := 0 to n-1 do
      begin
        e := GetLoginLog(i);
        if IsRootUser(e.usuario) then Continue;
        if prevIdx <> -1 then
          dot.Add(Format('  n%d -> n%d;', [prevIdx, i]));
        prevIdx := i;
      end;

      if prevIdx = -1 then
        dot.Add('  empty [shape=box, label="(sin registros de usuarios)"];');
    end;

    dot.Add('}');
    dot.SaveToFile(rutaDot);
  finally
    dot.Free;
  end;

  RunDot(rutaDot, rutaPng);
end;

procedure GenerarReporteMiLogueoPorEmail(const UsuarioEmail: String);
var
  usuarioCarp, dirU, dotFile, pngFile, dotPath: String;
  f: Text;
  i, idx, n: Integer;
  e: TLogEntry;
  P: TProcess;
begin
  usuarioCarp := Copy(UsuarioEmail, 1, Pos('@', UsuarioEmail) - 1);
  if usuarioCarp = '' then usuarioCarp := 'usuario';
  dirU := usuarioCarp + '-Reportes' + DirectorySeparator;
  ForceDirectories(dirU);

  dotFile := dirU + 'mi_logueo.dot';
  pngFile := dirU + 'mi_logueo.png';

  Assign(f, dotFile); Rewrite(f);
  try
    Writeln(f, 'digraph MiLogueo {');
    Writeln(f, '  rankdir=TB;');
    Writeln(f, '  node [shape=box, style="rounded", fontname="Helvetica"];');

    idx := 0;
    n := LoginLogCount;
    for i := 0 to n - 1 do
    begin
      e := GetLoginLog(i);
      if SameText(Trim(e.usuario), Trim(UsuarioEmail)) then
      begin
        Inc(idx);
        Writeln(f, Format('  n%d [label="Entrada: %s\lSalida: %s"];',
                 [idx,
                  StringReplace(e.entrada, '"','\"',[rfReplaceAll]),
                  StringReplace(e.salida , '"','\"',[rfReplaceAll])]));
        if idx > 1 then
          Writeln(f, Format('  n%d -> n%d;', [idx-1, idx]));
      end;
    end;

    if idx = 0 then
      Writeln(f, '  empty [label="(sin registros)"];');

    Writeln(f, '}');
  finally
    Close(f);
  end;

  dotPath := FindDefaultExecutablePath({$IFDEF WINDOWS}'dot.exe'{$ELSE}'dot'{$ENDIF});
  if (dotPath = '') and FileExists('/usr/bin/dot') then dotPath := '/usr/bin/dot';

  if (dotPath <> '') then
  begin
    P := TProcess.Create(nil);
    try
      P.Executable := dotPath;
      P.Parameters.Add('-Tpng');
      P.Parameters.Add(dotFile);
      P.Parameters.Add('-o');
      P.Parameters.Add(pngFile);
      P.Options := [poWaitOnExit];
      P.Execute;
    finally
      P.Free;
    end;
  end;
end;



end.

