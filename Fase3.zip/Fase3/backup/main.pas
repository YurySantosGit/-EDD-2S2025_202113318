unit main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls,
  app_state;

type

  { TForm1 }

  TForm1 = class(TForm)
    BtnLogin: TButton;
    BtnRegistrar: TButton;
    EditPassword: TEdit;
    EditEmail: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    LblMensaje: TLabel;
    procedure BtnLoginClick(Sender: TObject);
    procedure BtnRegistrarClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);

  private

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

uses
  usuarios, form_root, form_usuario, pila_papelera, cola_correos, form_bandeja,
  lista_doble, form_registro, contactos, bandejas, comunidades, app_state;

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  InicializarUsuarios;
  CargarUsuariosDesdeJSON('usuarios.json');
  if not ExisteEmail('root@edd.com') then
    AgregarUsuario(0, 'Administrador', 'root', 'root@edd.com', '00000000', 'root123');

  InicializarPapelera(PapeleraGlobal);
  InicializarCola(ColaGlobal);
  //InicializarBandeja(BandejaActual);
  InicializarBandejas;

  InicializarContactos(ListaContactos);
  CargarContactosDesdeJSON(ListaContactos, 'contactos.json');
  InicializarComunidades(ListaComunidades);

  AppStateInit;


end;

procedure TForm1.BtnLoginClick(Sender: TObject);
var
  user: PUsuario;
begin
  user := BuscarUsuarioPorEmail(EditEmail.Text, EditPassword.Text);

  if user <> nil then
  begin
    UsuarioActualEmail := user^.email;
    RegistrarLogin(user^.email, FormatDateTime('dd/mm/yyyy hh:nn', Now));
    //Usuario Root
    if user^.email = 'root@edd.com' then
    begin
      FormRoot := TFormRoot.Create(Self);
      FormRoot.Show;
      Self.Hide;
    end
    else
    begin
      //Usuario Estandar
      FormUsuario := TFormUsuario.Create(Self);
      FormUsuario.Show;
      Self.Hide;
    end;
  end
  else
  begin
    LblMensaje.Caption := 'Credenciales inválidas';
    LblMensaje.Font.Color := clRed;   // Error en rojo
  end;
end;

procedure TForm1.BtnRegistrarClick(Sender: TObject);
begin
  FormRegistro := TFormRegistro.Create(Self);
  FormRegistro.ShowModal;
end;

end.

